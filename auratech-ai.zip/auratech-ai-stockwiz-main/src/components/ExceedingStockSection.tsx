import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { InventoryData } from "@/lib/csvParser";
import { PackageCheck } from "lucide-react";

interface ExceedingStockSectionProps {
  data: InventoryData[];
}

export function ExceedingStockSection({ data }: ExceedingStockSectionProps) {
  const exceedingProducts = useMemo(() => {
    const productStock = data.reduce((acc, item) => {
      if (!acc[item.productId]) {
        acc[item.productId] = {
          productId: item.productId,
          category: item.category,
          region: item.region,
          avgInventory: 0,
          avgDemand: 0,
          count: 0,
          totalCost: 0
        };
      }
      acc[item.productId].avgInventory += item.inventoryLevel;
      acc[item.productId].avgDemand += item.demandForecast;
      acc[item.productId].totalCost += item.totalCost;
      acc[item.productId].count += 1;
      return acc;
    }, {} as Record<string, any>);

    let products = Object.values(productStock)
      .map(p => ({
        ...p,
        avgInventory: p.avgInventory / p.count,
        avgDemand: p.avgDemand / p.count,
        overstock: (p.avgInventory / p.count) - (p.avgDemand / p.count)
      }))
      .filter(p => p.overstock > 50)
      .sort((a, b) => b.overstock - a.overstock)
      .slice(0, 8);

    return products;
  }, [data]);

  return (
    <Card className="shadow-card hover:shadow-card-hover transition-shadow">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <PackageCheck className="h-6 w-6 text-warning" />
          Exceeding Stock
        </CardTitle>
        <CardDescription>Products with inventory significantly above demand</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {exceedingProducts.map((product) => (
            <div
              key={product.productId}
              className="p-4 rounded-lg bg-gradient-card border border-border hover:border-warning/50 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold text-foreground">{product.productId}</p>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                </div>
                <Badge variant="outline" className="border-warning text-warning">
                  Overstock
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-muted-foreground">Inventory</p>
                  <p className="font-semibold text-foreground">{product.avgInventory.toFixed(0)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Demand</p>
                  <p className="font-semibold text-foreground">{product.avgDemand.toFixed(0)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Excess</p>
                  <p className="font-semibold text-warning">+{product.overstock.toFixed(0)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Region</p>
                  <p className="font-semibold text-foreground">{product.region}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
