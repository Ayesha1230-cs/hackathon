import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { InventoryData } from "@/lib/csvParser";
import { AlertTriangle } from "lucide-react";

interface OutOfStockSectionProps {
  data: InventoryData[];
}

export function OutOfStockSection({ data }: OutOfStockSectionProps) {
  const outOfStockProducts = useMemo(() => {
    const productStock = data.reduce((acc, item) => {
      if (!acc[item.productId]) {
        acc[item.productId] = {
          productId: item.productId,
          category: item.category,
          region: item.region,
          avgInventory: 0,
          avgDemand: 0,
          count: 0,
          unitsSold: 0
        };
      }
      acc[item.productId].avgInventory += item.inventoryLevel;
      acc[item.productId].avgDemand += item.demandForecast;
      acc[item.productId].unitsSold += item.unitsSold;
      acc[item.productId].count += 1;
      return acc;
    }, {} as Record<string, any>);

    let products = Object.values(productStock)
      .map(p => ({
        ...p,
        avgInventory: p.avgInventory / p.count,
        avgDemand: p.avgDemand / p.count,
        shortage: (p.avgDemand / p.count) - (p.avgInventory / p.count)
      }))
      .filter(p => p.avgInventory < 150 || p.shortage > 0)
      .sort((a, b) => b.shortage - a.shortage)
      .slice(0, 6);

    return products;
  }, [data]);

  return (
    <Card className="shadow-card hover:shadow-card-hover transition-shadow border-destructive/20">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          Low Stock & Out of Stock
        </CardTitle>
        <CardDescription>Products requiring immediate attention</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {outOfStockProducts.map((product) => (
            <div
              key={product.productId}
              className="p-4 rounded-lg bg-gradient-card border border-destructive/30 hover:border-destructive/60 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{product.productId}</p>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                </div>
                <Badge variant="destructive" className="shrink-0">
                  Alert
                </Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Current Stock</span>
                  <span className="font-semibold text-destructive">{product.avgInventory.toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Required</span>
                  <span className="font-semibold text-foreground">{product.avgDemand.toFixed(0)}</span>
                </div>
                {product.shortage > 0 && (
                  <div className="flex justify-between pt-2 border-t border-border">
                    <span className="text-muted-foreground">Shortage</span>
                    <span className="font-semibold text-destructive">-{product.shortage.toFixed(0)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-border">
                  <Badge variant="secondary" className="w-full justify-center">
                    {product.region}
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
