import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { InventoryData } from "@/lib/csvParser";
import { TrendingUp } from "lucide-react";

interface DemandSectionProps {
  data: InventoryData[];
}

export function DemandSection({ data }: DemandSectionProps) {
  const [selectedRegion, setSelectedRegion] = useState<string>("all");
  const [sortOrder, setSortOrder] = useState<string>("high-to-low");

  const regions = useMemo(() => {
    const uniqueRegions = Array.from(new Set(data.map(item => item.region)));
    return ["all", ...uniqueRegions];
  }, [data]);

  const highDemandProducts = useMemo(() => {
    let filtered = data;
    
    if (selectedRegion !== "all") {
      filtered = data.filter(item => item.region === selectedRegion);
    }

    const productDemand = filtered.reduce((acc, item) => {
      if (!acc[item.productId]) {
        acc[item.productId] = {
          productId: item.productId,
          category: item.category,
          region: item.region,
          totalDemand: 0,
          avgDemand: 0,
          count: 0
        };
      }
      acc[item.productId].totalDemand += item.demandForecast;
      acc[item.productId].count += 1;
      return acc;
    }, {} as Record<string, any>);

    let products = Object.values(productDemand).map(p => ({
      ...p,
      avgDemand: p.totalDemand / p.count
    }));

    products.sort((a, b) => 
      sortOrder === "high-to-low" 
        ? b.avgDemand - a.avgDemand 
        : a.avgDemand - b.avgDemand
    );

    return products.slice(0, 10);
  }, [data, selectedRegion, sortOrder]);

  return (
    <Card className="shadow-card hover:shadow-card-hover transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-accent" />
              High Demand Products
            </CardTitle>
            <CardDescription>Products with highest forecasted demand</CardDescription>
          </div>
          <div className="flex gap-2">
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {regions.map(region => (
                  <SelectItem key={region} value={region}>
                    {region === "all" ? "All Regions" : region}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortOrder} onValueChange={setSortOrder}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high-to-low">High to Low</SelectItem>
                <SelectItem value="low-to-high">Low to High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {highDemandProducts.map((product, index) => (
            <div
              key={product.productId}
              className="flex items-center justify-between p-4 rounded-lg bg-gradient-card border border-border hover:border-primary/50 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary/10 text-primary font-bold">
                  {index + 1}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{product.productId}</p>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Badge variant="secondary" className="font-mono">
                  {product.region}
                </Badge>
                <div className="text-right">
                  <p className="text-lg font-bold text-accent">{product.avgDemand.toFixed(1)}</p>
                  <p className="text-xs text-muted-foreground">Avg Demand</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
