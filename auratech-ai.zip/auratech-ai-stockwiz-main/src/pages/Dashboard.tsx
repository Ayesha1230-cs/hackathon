import { useEffect, useState } from "react";
import { parseInventoryCSV, InventoryData } from "@/lib/csvParser";
import { SalesTrendChart } from "@/components/SalesTrendChart";
import { DemandSection } from "@/components/DemandSection";
import { ExceedingStockSection } from "@/components/ExceedingStockSection";
import { OutOfStockSection } from "@/components/OutOfStockSection";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const [data, setData] = useState<InventoryData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    parseInventoryCSV()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-2">Dashboard Overview</h2>
        <p className="text-muted-foreground">Smart inventory optimization powered by AI/ML forecasting</p>
      </div>

      <SalesTrendChart data={data} />

      <DemandSection data={data} />

      <ExceedingStockSection data={data} />

      <OutOfStockSection data={data} />
    </div>
  );
}
