import { useEffect, useState, useMemo } from "react";
import { parseInventoryCSV, InventoryData } from "@/lib/csvParser";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, DollarSign, TrendingUp, TrendingDown } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function PriceOptimization() {
  const [data, setData] = useState<InventoryData[]>([]);
  const [loading, setLoading] = useState(true);
  const [forecastData, setForecastData] = useState<any[]>([]);
  const [optimizations, setOptimizations] = useState<any[]>([]);
  const [forecastLoading, setForecastLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    parseInventoryCSV()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  // Generate 90-day forecast
  useEffect(() => {
    if (data.length === 0) return;

    const fetchForecast = async () => {
      setForecastLoading(true);
      try {
        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/forecast-demand`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            },
            body: JSON.stringify({
              historicalData: data,
              productId: "aggregate",
              days: 90,
            }),
          }
        );

        if (response.ok) {
          const result = await response.json();
          setForecastData(result.forecast || []);
        }
      } catch (error) {
        console.error("Forecast error:", error);
        toast({
          title: "Forecast Generation",
          description: "Using simulated forecast data",
          variant: "default",
        });
        
        // Generate simulated 90-day forecast
        const simulated = Array.from({ length: 90 }, (_, i) => {
          const date = new Date();
          date.setDate(date.getDate() + i);
          const baselineDemand = 500 + Math.sin(i / 7) * 100;
          return {
            date: date.toISOString().split('T')[0],
            predictedDemand: Math.round(baselineDemand + Math.random() * 50),
            confidence: 0.75 + Math.random() * 0.2,
          };
        });
        setForecastData(simulated);
      } finally {
        setForecastLoading(false);
      }
    };

    fetchForecast();
  }, [data, toast]);

  // Price optimization analysis
  const products = useMemo(() => {
    const productMap = new Map();

    data.forEach(item => {
      if (!productMap.has(item.productId)) {
        productMap.set(item.productId, {
          productId: item.productId,
          category: item.category,
          inventoryLevel: 0,
          demandForecast: 0,
          price: 0,
          count: 0,
        });
      }
      const p = productMap.get(item.productId);
      p.inventoryLevel += item.inventoryLevel;
      p.demandForecast += item.demandForecast;
      p.price += item.price;
      p.count += 1;
    });

    return Array.from(productMap.values()).map(p => {
      p.demandForecast /= p.count;
      p.price /= p.count;
      
      // Determine status and optimization
      let status = 'normal';
      let optimizedPrice = p.price;
      let priceChange = 0;
      
      if (p.inventoryLevel < p.demandForecast * 0.2) {
        status = 'out-of-stock';
        optimizedPrice = p.price * 1.15; // Increase 15%
        priceChange = 15;
      } else if (p.inventoryLevel > p.demandForecast * 3) {
        status = 'exceeding';
        optimizedPrice = p.price * 0.85; // Decrease 15%
        priceChange = -15;
      }
      
      return {
        productId: p.productId,
        category: p.category,
        currentPrice: p.price,
        optimizedPrice,
        priceChange,
        status,
        inventoryLevel: p.inventoryLevel,
        demand: p.demandForecast,
      };
    });
  }, [data]);

  const priceChartData = products.slice(0, 10).map(p => ({
    product: p.productId,
    current: p.currentPrice,
    optimized: p.optimizedPrice,
  }));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-2">Price Optimization</h2>
        <p className="text-muted-foreground">AI-powered pricing and 90-day demand forecasting</p>
      </div>

      {/* 90-Day Forecast */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-primary" />
            90-Day Demand Forecast
          </CardTitle>
        </CardHeader>
        <CardContent>
          {forecastLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs"
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return `${date.getMonth() + 1}/${date.getDate()}`;
                  }}
                />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="predictedDemand" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  name="Predicted Demand"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Price Optimization Chart */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-6 w-6 text-primary" />
            Price Optimization Analysis (Top 10 Products)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={priceChartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="product" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="current" fill="hsl(var(--muted))" name="Current Price" />
              <Bar dataKey="optimized" fill="hsl(var(--primary))" name="Optimized Price" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Optimization Details */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle>All Products Price Optimization</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {products.map((product) => (
              <div 
                key={product.productId}
                className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <span className="font-semibold">{product.productId}</span>
                    <Badge variant="outline">{product.category}</Badge>
                    <Badge 
                      variant={
                        product.status === 'out-of-stock' ? 'destructive' :
                        product.status === 'exceeding' ? 'default' :
                        'secondary'
                      }
                    >
                      {product.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Inventory: {product.inventoryLevel} | Demand: {Math.round(product.demand)}
                  </p>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Current</p>
                    <p className="text-lg font-semibold">${product.currentPrice.toFixed(2)}</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {product.priceChange > 0 ? (
                      <TrendingUp className="h-5 w-5 text-success" />
                    ) : product.priceChange < 0 ? (
                      <TrendingDown className="h-5 w-5 text-destructive" />
                    ) : null}
                    <span className={`font-medium ${
                      product.priceChange > 0 ? 'text-success' :
                      product.priceChange < 0 ? 'text-destructive' :
                      'text-muted-foreground'
                    }`}>
                      {product.priceChange > 0 ? '+' : ''}{product.priceChange}%
                    </span>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Optimized</p>
                    <p className="text-lg font-semibold text-primary">
                      ${product.optimizedPrice.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
