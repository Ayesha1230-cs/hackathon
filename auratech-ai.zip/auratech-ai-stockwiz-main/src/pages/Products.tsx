import { useEffect, useState, useMemo } from "react";
import { parseInventoryCSV, InventoryData } from "@/lib/csvParser";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Package, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Products() {
  const [data, setData] = useState<InventoryData[]>([]);
  const [loading, setLoading] = useState(true);
  const [demandFilter, setDemandFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [stockFilter, setStockFilter] = useState<string>("all");

  useEffect(() => {
    parseInventoryCSV()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  // Aggregate products
  const products = useMemo(() => {
    const productMap = new Map<string, {
      productId: string;
      category: string;
      totalInventory: number;
      totalSold: number;
      avgDemand: number;
      avgPrice: number;
      status: 'out-of-stock' | 'exceeding' | 'normal';
      regions: Set<string>;
    }>();

    data.forEach(item => {
      if (!productMap.has(item.productId)) {
        productMap.set(item.productId, {
          productId: item.productId,
          category: item.category,
          totalInventory: 0,
          totalSold: 0,
          avgDemand: 0,
          avgPrice: 0,
          status: 'normal',
          regions: new Set(),
        });
      }
      const product = productMap.get(item.productId)!;
      product.totalInventory += item.inventoryLevel;
      product.totalSold += item.unitsSold;
      product.avgDemand += item.demandForecast;
      product.avgPrice += item.price;
      product.regions.add(item.region);
    });

    return Array.from(productMap.values()).map(p => {
      const count = data.filter(d => d.productId === p.productId).length;
      p.avgDemand /= count;
      p.avgPrice /= count;
      
      // Determine status
      if (p.totalInventory < p.avgDemand * 0.2) {
        p.status = 'out-of-stock';
      } else if (p.totalInventory > p.avgDemand * 3) {
        p.status = 'exceeding';
      }
      
      return p;
    });
  }, [data]);

  // Apply filters
  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    if (categoryFilter !== "all") {
      filtered = filtered.filter(p => p.category === categoryFilter);
    }

    if (stockFilter !== "all") {
      filtered = filtered.filter(p => p.status === stockFilter);
    }

    // Sort by demand
    if (demandFilter === "high-to-low") {
      filtered.sort((a, b) => b.avgDemand - a.avgDemand);
    } else if (demandFilter === "low-to-high") {
      filtered.sort((a, b) => a.avgDemand - b.avgDemand);
    }

    return filtered;
  }, [products, demandFilter, categoryFilter, stockFilter]);

  const categories = useMemo(() => {
    return Array.from(new Set(data.map(d => d.category)));
  }, [data]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-2">Products</h2>
        <p className="text-muted-foreground">Manage your product inventory and analyze demand</p>
      </div>

      {/* Filters */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-6 w-6 text-primary" />
            Product Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Demand</label>
              <Select value={demandFilter} onValueChange={setDemandFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Demand Levels</SelectItem>
                  <SelectItem value="high-to-low">High to Low</SelectItem>
                  <SelectItem value="low-to-high">Low to High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Category</label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Stock Status</label>
              <Select value={stockFilter} onValueChange={setStockFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stock Levels</SelectItem>
                  <SelectItem value="out-of-stock">Out of Stock</SelectItem>
                  <SelectItem value="exceeding">Exceeding Stock</SelectItem>
                  <SelectItem value="normal">Normal Stock</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle>All Products ({filteredProducts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product ID</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Inventory</TableHead>
                  <TableHead>Avg Demand</TableHead>
                  <TableHead>Total Sold</TableHead>
                  <TableHead>Avg Price</TableHead>
                  <TableHead>Regions</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.productId}>
                    <TableCell className="font-medium">{product.productId}</TableCell>
                    <TableCell>{product.category}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {product.totalInventory}
                        {product.status === 'out-of-stock' && (
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                        )}
                        {product.status === 'exceeding' && (
                          <TrendingUp className="h-4 w-4 text-warning" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{Math.round(product.avgDemand)}</TableCell>
                    <TableCell>{product.totalSold}</TableCell>
                    <TableCell>${product.avgPrice.toFixed(2)}</TableCell>
                    <TableCell>{product.regions.size} regions</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          product.status === 'out-of-stock' ? 'destructive' :
                          product.status === 'exceeding' ? 'default' :
                          'secondary'
                        }
                      >
                        {product.status === 'out-of-stock' ? 'Out of Stock' :
                         product.status === 'exceeding' ? 'Exceeding' :
                         'Normal'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
