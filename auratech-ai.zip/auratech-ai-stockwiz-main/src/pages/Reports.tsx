import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function Reports() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-2">Reports</h2>
        <p className="text-muted-foreground">Generate and view detailed inventory reports</p>
      </div>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-primary" />
            Reports & Analytics
          </CardTitle>
          <CardDescription>Coming soon - Comprehensive reporting tools</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12 text-muted-foreground">
            <p>Reporting features will be available here</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
