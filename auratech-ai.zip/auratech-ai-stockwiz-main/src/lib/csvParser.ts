export interface InventoryData {
  date: string;
  storeId: string;
  productId: string;
  category: string;
  region: string;
  inventoryLevel: number;
  unitsSold: number;
  unitsOrdered: number;
  demandForecast: number;
  price: number;
  discount: number;
  totalCost: number;
}

export async function parseInventoryCSV(): Promise<InventoryData[]> {
  const response = await fetch('/data/inventory_data.csv');
  const text = await response.text();
  const lines = text.split('\n');
  const data: InventoryData[] = [];

  // Skip header
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const values = line.split(',');
    if (values.length < 12) continue;

    data.push({
      date: values[0],
      storeId: values[1],
      productId: values[2],
      category: values[3],
      region: values[4],
      inventoryLevel: parseFloat(values[5]) || 0,
      unitsSold: parseFloat(values[6]) || 0,
      unitsOrdered: parseFloat(values[7]) || 0,
      demandForecast: parseFloat(values[8]) || 0,
      price: parseFloat(values[9]) || 0,
      discount: parseFloat(values[10]) || 0,
      totalCost: parseFloat(values[11]) || 0,
    });
  }

  return data;
}
